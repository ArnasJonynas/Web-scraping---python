import os
import secrets
from flask import render_template, url_for, flash, redirect, request
from flaskweb import app, db
from flaskweb.forms import CategoryForm
from flaskweb.models import Category, Item, Price


@app.route("/")
@app.route("/home")
def home():
    categorys = Category.query.all()
    items = Item.query.all()
    price = Price.query.all()
    return render_template('home.html', categorys=categorys, items=items, price=price )


@app.route("/post/new", methods=['GET', 'POST'])
def new_post():
    form = CategoryForm()
    if form.validate_on_submit():
        post = Category(name=form.name.data)
        db.session.add(post)
        db.session.commit()
        flash('Your category has been created!', 'success')
        return redirect(url_for('home'))
    return render_template('create_category.html', title='New Category',
                           form=form, )


@app.route("/post/<int:category_id>")
def post(category_id):
    category = Category.query.get_or_404(category_id)
    items = Item.query.all()
    price = Price.query.all()
    return render_template('category.html', title=category.name, category=category, items=items, price=price)


@app.route("/post/<int:category_id>/update", methods=['GET', 'POST'])
def update_post(category_id):
    post = Category.query.get_or_404(category_id)
    form = CategoryForm()
    if form.validate_on_submit():
        post.title = form.name.data
        db.session.commit()
        flash('Your category has been updated!', 'success')
        return redirect(url_for('post', category_id=post.id))
    elif request.method == 'GET':
        form.name.data = post.name
    return render_template('create_category.html', title='Update category',
                           form=form)


@app.route("/post/<int:category_id>/delete", methods=['POST'])
def delete_post(category_id):
    category = Category.query.get_or_404(category_id)
    db.session.delete(category)
    db.session.commit()
    flash('Your category has been deleted!', 'success')
    return redirect(url_for('home'))
	
	
@app.route('/search/',methods = ['POST', 'GET'])
def search():
   if request.method == 'POST':
      nameget = request.form['nm']
      items = Item.query.all()
      price = Price.query.all()
      categorys = Category.query.filter(Category.name.like('%' + nameget + '%'))
      return render_template('home.html', categorys=categorys, items=items, price=price )
   else:
      nameget = request.args.get('nm')
      items = Item.query.all()
      price = Price.query.all()
      categorys = Category.query.filter(Category.name.like(nameget))
      return render_template('home.html', categorys=categorys, items=items, price=price )
	

