from flaskweb import db

class Category(db.Model):
	
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    items = db.relationship('Item', backref='author', lazy=True)
	
    
    def __repr__(self):
        return f"Category('{self.name}')"
		
class Item(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    item = db.Column(db.String(100), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=False)
    price = db.relationship('Price', backref='author', lazy=True)
    
    def __repr__(self):
        return f"Item('{self.item_name}')"
		
class Price(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    price = db.Column(db.String(100), nullable=False)
    item_id = db.Column(db.Integer, db.ForeignKey('item.id'), nullable=False)
    
    def __repr__(self):
        return f"Price('{self.price}')"
		

