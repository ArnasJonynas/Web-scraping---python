import json

def readJsonFile(filename):
    with open(filename, 'r') as f:
        dict = json.load(f)

    return dict