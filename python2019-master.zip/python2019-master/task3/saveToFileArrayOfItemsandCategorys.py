import csv

def saveToFileArrayOfItemsAndCategorys(array):
    with open("out.txt", "w") as f:
        wr = csv.writer(f)
        wr.writerows(array)
