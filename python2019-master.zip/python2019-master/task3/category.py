category_FileName = 'category.json'

class Category(object):
    def __init__(self, data):
        self.__dict__ = data

    def calculateHowManyCategorys(self):
        return len(self.__dict__)

    def printCategorys(self):
        return self.__dict__.values()

    def listOfCategorys(self):
        return list(self.__dict__.values())

    def addCategoryToArray(self):
        categorysWithItems = []
        categorys_list = self.listOfCategorys()
        i = 0
        lenOfCategorys = self.calculateHowManyCategorys()
        while i < lenOfCategorys:
            categorysWithItems.append(
                [])  # kasko reikia vis prideti po nauja masyva kittaip neveikia nes nera kitos pozicijos
            categorysWithItems[i].append(categorys_list[i])
            i += 1
        return categorysWithItems





