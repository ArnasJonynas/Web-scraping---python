import category
import item
import price
import readJsonFile
import savePriceThings
import saveToFileArrayOfItemsandCategorys


def addItemsToCategorys():
  # take dict
  categorys = category_object.printCategorys()
  itemsValue = item_object.printItemsValues()
  itemsKeys = item_object.printItemsKey()

  # turn into list to have indexsing
  categorys_list = list(categorys)
  itemsKeys_list = list(itemsKeys)
  itemsValue_list = list(itemsValue)

  # check
  # print(categorys_list)
  # print(itemsKeys_list)
  # print(itemsValue_list)

  # combine items to categorys
  lenOfCategorys = len(categorys_list)
  lenOfItems = len(itemsKeys_list)
  i = 0

  arrayWithCategorysAndItems = category_object.addCategoryToArray()
  while i < lenOfItems:
    p = 0
    while p < lenOfCategorys:
      if arrayWithCategorysAndItems[p][0] == itemsValue_list[i]:
        arrayWithCategorysAndItems[p].append(itemsKeys_list[i])
      p += 1
    i += 1

  return arrayWithCategorysAndItems


def howManyItemsHaveCategorys():
  array = addItemsToCategorys()
  len = category_object.calculateHowManyCategorys()
  howMany = dict()
  i = 0
  while i < len:
    p = 0
    value = 0
    key = array[i][0]
    while p < array[i].__len__():
      value += 1
      p += 1
    value = value - 1
    howMany[key] = value
    i += 1
  print(howMany)


def printCategorysWithItems():
  array = addItemsToCategorys()
  lenArray = len(array)
  i = 0
  while i < lenArray:
    print(array[i])
    i += 1


if __name__ == '__main__':


  category_dict = readJsonFile.readJsonFile(category.category_FileName)
  item_dict = readJsonFile.readJsonFile(item.item_FileName)
  price_dict = readJsonFile.readJsonFile(price.price_FileName)

  #convert to objects
  category_object = category.Category(category_dict)
  item_object = item.Item(item_dict)
  price_object = price.Price(price_dict)

  #someusefullfunti

  print(category_object.__dict__)
  print("Where are ",  category_object.calculateHowManyCategorys(), "categorys of items", category_object.printCategorys() )
  print(item_object.__dict__)
  print("Where are ", category_object.calculateHowManyCategorys(), "categorys of items")
  print(price_object.__dict__)
  printCategorysWithItems() # putting all items to categorys

 #functions with price
  name = "Blue_Partyhat"
  print("The price of", name , "is: ", price_object.getPrice(name))
  print("The total price of all items is:", price_object.getTotalPriceOfAllItems())
  mostPrice, mostValueItems = price_object.getMostValueItem()
  print("Biggest price is:", mostPrice, "and the items:", mostValueItems)
  howManyItemsHaveCategorys()

  #saveInfoToFile
  array = addItemsToCategorys()
  saveToFileArrayOfItemsandCategorys.saveToFileArrayOfItemsAndCategorys(array)
  mostPrice, mostValueItems = price_object.getMostValueItem()
  savePriceThings.savePriceThings( mostPrice, mostValueItems)