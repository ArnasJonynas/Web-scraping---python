from bs4 import BeautifulSoup
import requests
import re
import json

import jsonsave

if __name__ == '__main__':

    """Category"""
    source = requests.get('http://services.runescape.com/m=itemdb_rs/').text
    soup = BeautifulSoup(source, 'lxml')


    articleOfCatalogue =  soup.find('article', class_='catalogue')
    for link in articleOfCatalogue.findAll('a', attrs={'href': re.compile("^http://")}):
        cataloguelink=link.get('href')


    #Getting all categorys
    categorysdict = dict()
    print(cataloguelink)
    index = 1

    categorysSource = requests.get(cataloguelink).text
    categorysSoup = BeautifulSoup(categorysSource, 'lxml')
    for ultag in categorysSoup.find_all('div', {'class': 'categories'}):
        for litag in ultag.find_all('li'):
            categorysdict[index] = litag.text
            index += 1

    #save into json file
    jsonCategory = json.dumps(categorysdict)
    #print(my_json_string)
    jsonsave.saveCategorys(jsonCategory)

    """Category"""

    #get item links
    itemslinks = []
    for ultag in categorysSoup.find_all('div', {'class': 'categories'}):
        for litag in ultag.find_all('a'):
            itemslinks.append(litag.get('href'))

    # links of all caltegorys to they items
    indexingCategorys = 0
    categoryAndLink = dict()
    for namesCategory in categorysdict:
        yas1 = cataloguelink + "?" + (itemslinks[indexingCategorys].split('?'))[1]
        yas2 = categorysdict.get(namesCategory)
        categoryAndLink[yas2] = yas1
        indexingCategorys += 1

    #allCategorysAndLinkToTheyItems
    #print(categoryAndLink)

    """Item"""
    #link generating to for one category items
    linkToItems = cataloguelink + "?" + (itemslinks[0].split('?'))[1]
    print(linkToItems)

    itemsDict1 = dict()
    itemAndPriceDict1 = dict()

    for key, value  in categoryAndLink.items():
        itemSource1 = requests.get(value).text
        itemSoup1 = BeautifulSoup(itemSource1, 'lxml')
        itemtable1 = itemSoup1.find('table')
        itembody1 = itemtable1.find('tbody')
        for names1 in itembody1.findAll("tr"):
            yasname1 = names1.find("span")
            itemTrueName1 = yasname1.text
            itemsDict1[itemTrueName1] = key
            priceOfitem1 = ((names1.text).split("\n"))[8]
            itemAndPriceDict1[itemTrueName1] = priceOfitem1

    #prototipe of item scraping
    itemSource = requests.get(linkToItems).text
    itemSoup = BeautifulSoup(itemSource, 'lxml')

    #dict to save item and they category
    itemsDict = dict()
    itemAndPriceDict = dict()




    nameOfCategory = categorysdict[1]
    itemtable = itemSoup.find('table')
    itembody = itemtable.find('tbody')
    for names in itembody.findAll("tr"):
        yasname = names.find("span")
        itemTrueName = yasname.text
        itemsDict[itemTrueName] = nameOfCategory
        priceOfitem = ((names.text).split("\n"))[8]
        itemAndPriceDict[itemTrueName] = priceOfitem

    #itemsobject to json
    jsonItem = json.dumps(itemsDict)
    jsonsave.saveItems(jsonItem)

    #priceobject to json
    jsonPrice = json.dumps(itemAndPriceDict1)
    jsonsave.savePrice(jsonPrice)

    """Item"""
