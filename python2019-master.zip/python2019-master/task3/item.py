item_FileName = 'item.json'


class Item(object):
    def __init__(self, data):
        self.__dict__ = data

    def calculateHowManyItem(self):
        return len(self.__dict__)

    def printItemsValues(self):
        return self.__dict__.values()

    def printItemsKey(self):
        return self.__dict__.keys()

    def listOfItemsValue(self):
        return list(self.__dict__.values())

    def listOfItemsKey(self):
        return list(self.__dict__.keys())

