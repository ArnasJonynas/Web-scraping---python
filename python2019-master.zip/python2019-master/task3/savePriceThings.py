def savePriceThings(mostPrice, mostValueItems):
    with open("price.txt", "w") as f:
        f.write("Biggest price is: ")
        f.write(str(mostPrice))
        f.write(" and the items are: \n")
        i = 0
        while i < len(mostValueItems):
            f.write(mostValueItems[i])
            f.write(" ")
            i += 1

