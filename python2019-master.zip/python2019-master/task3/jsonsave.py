import io, json

def saveCategorys(file):
    with io.open('category.json', 'w', encoding='utf-8') as f:
      f.write(file)

def saveItems(file):
    with io.open('items1.json', 'w', encoding='utf-8') as f:
      f.write(file)

def savePrice(file):
    with io.open('price1.json', 'w', encoding='utf-8') as f:
      f.write(file)