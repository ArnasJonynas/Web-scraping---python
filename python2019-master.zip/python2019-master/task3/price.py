price_FileName = 'price.json'

class Price(object):
    def __init__(self, data):
        self.__dict__ = data

    def getPrice(self, name):
        price = float(self.__dict__[name])
        return price

    def getItemList(self):
        return list(self.__dict__.keys())

    def getPriceList(self):
        return list(self.__dict__.values())

    def getPriceLen(self):
        return len(self.__dict__)

    def getTotalPriceOfAllItems(self):
        list=self.getPriceList()
        total = 0
        a = 0
        len = self.getPriceLen()
        while a < len:
            total += float(list[a])
            a += 1
        return total

    def getMostValueItem(self):
        array = []
        listprice = self.getPriceList()
        listitem = self.getItemList()
        mostvalueprice = 0
        i = 0
        len = self.getPriceLen()
        while i < len:
            if mostvalueprice < listprice[i]:
                array.clear()
                array.append(listitem[i])
                mostvalueprice = listprice[i]
            elif mostvalueprice == listprice[i]:
                array.append(listitem[i])
            i += 1

        return mostvalueprice, array

