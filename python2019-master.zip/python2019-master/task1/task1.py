#!/usr/bin/env python
import sys
import os
import operator

''' rusiavimui '''


def howToUseIt():
    print("!!!!!!!!!!!!!!!Make sure your file name is correct and its is logfile!!!!!!!!!!!!!!!!!!!")
    print("write file name and option what would you like to do")
    print(" Options: ")
    print(" (ip) to see all ip and (1) to see count how many time visited sites")
    print(" (http) to see all sites and  (1) to see count how many people visited site")
    print(" (ip) to see all  ip and (2) to see percentage of which site visited max")
    print(" (http) to see all  sites and (2) to see percebtage of how many people visited")
    print(" (ip) to see all ip and (3) to see how many bytes trasferred of ip")
    print(" (http) to see all  sites and (3) to see percentage of site")
    print(" !!!!!!!!!!!Example!!!!!!!!!!!")
    print(" py task1.py logfile.txt ip 1")
    print(" !!!!!!!!!!!Example!!!!!!!!!!!")


'''

'''

''' 1'''

def number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False



def option1(filename, howMany, ipOrHttp):
    optionToTake = "ip"
    numberjust = 0
    yes = int(howMany)
    d = dict()
    if ipOrHttp == "ip":
        optionToTake = 0
    else:
        optionToTake = 8
    with open(filename, 'r') as logfile:
        for line in logfile:
            ip = line.split(" ")[optionToTake]
            if ip in d:
                d[ip] += 1
            else:
                d[ip] = 1
    if yes > 0:
        for keys, values in d.items():
            if numberjust < yes:
                numberjust += 1
                print(keys, ":", values)
    else:
        for keys, values in d.items():
            print(keys, ":", values)


        ''' 2 '''


def ip2(filename, howMany):
    numberjust = 0
    yes = int(howMany)
    howManyTimesConnected = 0
    d = dict()
    list = dict()
    with open(filename, 'r') as logfile:
        for line in logfile:
            howManyTimesConnected += 1
            ip = line.split(" ")[0]
            if ip in d:
                d[ip] += 1
            else:
                d[ip] = 1
    for keys, values in d.items():
        list[keys] = values / howManyTimesConnected * 100

    s = [(k, list[k]) for k in sorted(list, key=list.get, reverse=True)]

    if yes > 0:
        for keys, values in s:
            if numberjust < yes:
                numberjust += 1
                print(keys, ":", values)
    else:
        for k, v in s:
            print(k, v)



def http2(filename, howMany):
    numberjust = 0
    yes = int(howMany)
    howManyTimesConnected = 0
    d = dict()
    list = dict()
    with open(filename, 'r') as logfile:
        for line in logfile:
            howManyTimesConnected += 1
            http = line.split(" ")[8]
            if http in d:
                d[http] += 1
            else:
                d[http] = 1
    for keys, values in d.items():
        list[keys] = values / howManyTimesConnected * 100

    s = [(k, list[k]) for k in sorted(list, key=list.get, reverse=True)]

    if yes > 0:
        for keys, values in s:
            if numberjust < yes:
                numberjust += 1
                print(keys, ":", values)
    else:
        for k, v in s:
            print(k, v)

        ''' 2 '''

        ''' 3 '''


def ip3(filename, howMany):
    numberjust = 0
    yes = int(howMany)
    d = dict()

    with open(filename, 'r') as logfile:
        for line in logfile:
            s = line.split()[9]
            nuOrNot = number(s)
            if nuOrNot:
                numberOfBytes = int(s)
                ip = line.split()[0]
                if ip in d:
                    d[ip] += numberOfBytes
                else:
                    d[ip] = numberOfBytes
            else:
                pass
    if yes > 0:
        for keys, values in d.items():
            if numberjust < yes:
                numberjust += 1
                print(keys, ":", values)
    else:
        for keys, values in d.items():
            print(keys, ":", values)


def http3(filename, howMany):

    numberjust = 0
    yes = int(howMany)
    d = dict()
    with open(filename, 'r') as logfile:
        for line in logfile:
            bytes = line.split()[9]
            if number(bytes):
                numberOfBytes = int(bytes)
                httpstatus = line.split()[8]
                if httpstatus in d:
                    d[httpstatus] += numberOfBytes
                else:
                    d[httpstatus] = numberOfBytes
            else:
                pass
    if yes > 0:
        for keys, values in d.items():
            if numberjust < yes:
                numberjust += 1
                print(keys, ":", values)
    else:
        for keys, values in d.items():
            print(keys, ":", values)




def fileformat(filename):
    try:
        with open(filename, 'r') as logfile:
            first = logfile.read(1)
            if not first:
                return 0
            else:
                for line in logfile:
                    ip = line.split()[0]
                    countip = ip.count('.')
                    get = line.split()[5]
                    if countip == 3 and len(get) == 4:
                        return 1
                    else:
                        return 0
    except FileNotFoundError:
        return 0


''' Main'''
if __name__ == '__main__':

    if len(sys.argv) <= 2:
        howToUseIt()

    elif len(sys.argv) > 2:
        filename = sys.argv[1]
        file = fileformat(filename)
        if file == 1:
            ipOrHttp = sys.argv[2]

            if len(sys.argv) > 3:
                option = sys.argv[3]
                howMany = -1

                if len(sys.argv) > 4:
                    howMuch = sys.argv[4]
                    number2 = number(howMuch)
                    if number2:
                        howMany = int(howMuch)

                if option == "1":
                    option1(filename, howMany, ipOrHttp)

                elif option == "2":
                    if ipOrHttp == "ip":
                        ip2(filename, howMany)
                    if ipOrHttp == "http":
                        http2(filename, howMany)

                elif option == "3":
                    if ipOrHttp == "ip":
                        ip3(filename, howMany)
                    if ipOrHttp == "http":
                        http3(filename, howMany)

                else:
                    howToUseIt()
            else:
                howToUseIt()
        else:
            howToUseIt()
    else:
        howToUseIt()
