#!/usr/bin/env python
import sys
import os
import operator
import json
import numpy as np
import csv




"""  CLASS START """
class Category(object):
    def __init__(self, data):
        self.__dict__ = data

    def calculateHowManyCategorys(self):
        return len(self.__dict__)

    def printCategorys(self):
        return self.__dict__.values()

    def listOfCategorys(self):
        return list(self.__dict__.values())

    def addCategoryToArray(self):
        categorysWithItems = []
        categorys_list = self.listOfCategorys()
        i = 0
        lenOfCategorys = self.calculateHowManyCategorys()
        while i < lenOfCategorys:
            categorysWithItems.append(
                [])  # kasko reikia vis prideti po nauja masyva kittaip neveikia nes nera kitos pozicijos
            categorysWithItems[i].append(categorys_list[i])
            i += 1
        return categorysWithItems

class Item(object):
    def __init__(self, data):
        self.__dict__ = data

    def calculateHowManyItem(self):
        return len(self.__dict__)

    def printItemsValues(self):
        return self.__dict__.values()

    def printItemsKey(self):
        return self.__dict__.keys()

    def listOfItemsValue(self):
        return list(self.__dict__.values())

    def listOfItemsKey(self):
        return list(self.__dict__.keys())


class Price(object):
    def __init__(self, data):
        self.__dict__ = data

    def getPrice(self, name):
        price = self.__dict__[name]
        return price

    def getItemList(self):
        return list(self.__dict__.keys())

    def getPriceList(self):
        return list(self.__dict__.values())

    def getPriceLen(self):
        return len(self.__dict__)

    def getTotalPriceOfAllItems(self):
        list=self.getPriceList()
        total = 0
        a = 0
        len = self.getPriceLen()
        while a < len:
            total += int(list[a])
            a += 1
        return total

    def getMostValueItem(self):
        array = []
        listprice = self.getPriceList()
        listitem = self.getItemList()
        mostvalueprice = 0
        i = 0
        len = self.getPriceLen()
        while i < len:
            if mostvalueprice < listprice[i]:
                array.clear()
                array.append(listitem[i])
                mostvalueprice = listprice[i]
            elif mostvalueprice == listprice[i]:
                array.append(listitem[i])
            i += 1

        return mostvalueprice, array




"""  CLASS END """
def addItemsToCategorys():
  # take dict
  categorys = category_object.printCategorys()
  itemsValue = item_object.printItemsValues()
  itemsKeys = item_object.printItemsKey()

  # turn into list to have indexsing
  categorys_list = list(categorys)
  itemsKeys_list = list(itemsKeys)
  itemsValue_list = list(itemsValue)

  # check
  # print(categorys_list)
  # print(itemsKeys_list)
  # print(itemsValue_list)

  # combine items to categorys
  lenOfCategorys = len(categorys_list)
  lenOfItems = len(itemsKeys_list)
  i = 0

  arrayWithCategorysAndItems = category_object.addCategoryToArray()
  while i < lenOfItems:
    p = 0
    while p < lenOfCategorys:
      if arrayWithCategorysAndItems[p][0] == itemsValue_list[i]:
        arrayWithCategorysAndItems[p].append(itemsKeys_list[i])
      p += 1
    i += 1

  return arrayWithCategorysAndItems


def howManyItemsHaveCategorys():
  array = addItemsToCategorys()
  len = category_object.calculateHowManyCategorys()
  howMany = dict()
  i = 0
  while i < len:
    p = 0
    value = 0
    key = array[i][0]
    while p < array[i].__len__():
      value += 1
      p += 1
    value = value - 1
    howMany[key] = value
    i += 1
  print(howMany)


def printCategorysWithItems():
  array = addItemsToCategorys()
  lenArray = len(array)
  i = 0
  while i < lenArray:
    print(array[i])
    i += 1



def saveToFileArrayOfItemsAndCategorys():
    array = addItemsToCategorys()
    with open("out.txt", "w") as f:
        wr = csv.writer(f)
        wr.writerows(array)

def savePriceThings():

    mostPrice, mostValueItems = price_object.getMostValueItem()
    with open("price.txt", "w") as f:
        f.write("Biggest price is: ")
        f.write(str(mostPrice))
        f.write(" and the items are: \n")
        i = 0
        while i < len(mostValueItems):
            f.write(mostValueItems[i])
            f.write(" ")
            i += 1



def readJsonFile(filename):
    with open(filename, 'r') as f:
        dict = json.load(f)

    return dict


#Main
if __name__ == '__main__':

    #filenames
    category_FileName = 'category.json'
    item_FileName = 'item.json'
    price_FileName = 'price.json'
    #variables

    #readFiles
    category_dict = readJsonFile(category_FileName)
    item_dict = readJsonFile(item_FileName)
    price_dict = readJsonFile(price_FileName)


    #convert to objects
    category_object = Category(category_dict)
    item_object = Item(item_dict)
    price_object = Price(price_dict)

    #someusefullfunti

    #print(category_object.__dict__)
    #print("Where are ",  category_object.calculateHowManyCategorys(), "categorys of items", category_object.printCategorys() )
    #print(item_object.__dict__)
    #print("Where are ", category_object.calculateHowManyCategorys(), "categorys of items")
    #print(price_object.__dict__)
    printCategorysWithItems() # putting all items to categorys

    #functions with price
    name = "Blue_Partyhat"
    print("The price of", name , "is: ", price_object.getPrice(name))
    print("The total price of all items is:", price_object.getTotalPriceOfAllItems())
    mostPrice, mostValueItems = price_object.getMostValueItem()
    print("Biggest price is:", mostPrice, "and the items:", mostValueItems)
    howManyItemsHaveCategorys()

    #saveInfoToFile
    saveToFileArrayOfItemsAndCategorys()
    savePriceThings()


